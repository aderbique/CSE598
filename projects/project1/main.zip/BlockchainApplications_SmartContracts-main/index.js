'use strict';
const patientrecordcontract = require('./patientrecordcontract.js');
module.exports.contracts = [patientrecordcontract];
